//
//  TVShow.m
//  CoreDataProject
//
//  Created by Filipe Patrício on 26/05/15.
//  Copyright (c) 2015 Filipe Patrício. All rights reserved.
//

#import "TVShow.h"


@implementation TVShow

@dynamic title;
@dynamic numberOfSeasons;

@end
