//
//  NSString+Random.h
//  Models
//
//  Created by Daniel García on 17/05/14.
//  Copyright (c) 2014 Produkt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Random)
+ (NSString *)randomString;
@end
