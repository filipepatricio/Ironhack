//
//  Movie.m
//  Models
//
//  Created by Daniel García García on 18/05/14.
//  Copyright (c) 2014 Produkt. All rights reserved.
//

#import "Movie.h"

@implementation Movie

@end
